package com.zpharma.commons.web.constants;

public class ApplicationConfigPortletKeys {

	
	public static final String APPLICATIONCONFIG =
			"net_ayudh_portal_commons_web_ApplicationConfigPortlet";
	
}
