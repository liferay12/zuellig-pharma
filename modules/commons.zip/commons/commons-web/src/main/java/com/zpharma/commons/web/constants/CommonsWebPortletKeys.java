package com.zpharma.commons.web.constants;

/**
 * @author adj
 */
public class CommonsWebPortletKeys {

	public static final String COMMONSWEB =
		"com_zpharma_commons_web_CommonsWebPortlet";

}