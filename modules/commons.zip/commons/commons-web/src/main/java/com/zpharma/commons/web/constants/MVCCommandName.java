package com.zpharma.commons.web.constants;

public class MVCCommandName {
	public static final String SAVE_SITECONFIG="saveSiteConfig";
	
}

