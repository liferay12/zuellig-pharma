package com.zpharma.commons.web.constants;

public class ApplicationConfigPanelCategoryKeys {

	public static final String CONTROL_PANEL_CATEGORY = "ApplicationConfig";
	
}
